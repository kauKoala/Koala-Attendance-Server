# Selenium Python on AWS Lambda

### No needed the Docker and your credentials


```
I have the final zip(lambda_function.zip) file to upload in aws lambda and you can the edit the lambda_function.py for your requirements.
```

